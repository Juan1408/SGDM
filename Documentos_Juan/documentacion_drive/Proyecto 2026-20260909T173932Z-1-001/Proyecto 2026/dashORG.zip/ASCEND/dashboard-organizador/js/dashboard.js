/*
===========================================
    TORNEOS DEL ORGANIZADOR
===========================================
*/

const torneos = [

    {

        nombre: "LoL Summer Cup",

        disciplina: "League of Legends",

        estado: "Inscripciones abiertas",

        claseEstado: "abierta",

        categoria: "esports",

        equipos: "12 / 16 equipos",

        fecha: "15 Ago 2026",

        sistema: "Grupos + Eliminación",

        boton: "Administrar"

    },

    {

        nombre: "Copa Primavera",

        disciplina: "Fútbol",

        estado: "En juego",

        claseEstado: "curso",

        categoria: "deportes",

        equipos: "24 / 32 equipos",

        fecha: "22 Ago 2026",

        sistema: "Liga",

        boton: "Administrar"

    },

    {

        nombre: "Torneo Nacional",

        disciplina: "Ajedrez",

        estado: "Finalizado",

        claseEstado: "finalizado",

        categoria: "mesa",

        equipos: "64 jugadores",

        fecha: "Finalizado",

        sistema: "Sistema Suizo",

        boton: "Ver resultados"

    }

];
/*
===========================================
    CARGAR TORNEOS
===========================================
*/

const contenedor = document.getElementById("torneosGrid");

torneos.forEach(torneo => {

    contenedor.innerHTML += `

        <article class="torneo-card ${torneo.categoria}">

            <div class="torneo-info">

                <h3>${torneo.nombre}</h3>

                <p>${torneo.disciplina}</p>

                <span class="estado ${torneo.claseEstado}">

                    ${torneo.estado}

                </span>

                <div class="torneo-detalles">

                    <span>

                        <i class="fa-solid fa-users"></i>

                        ${torneo.equipos}

                    </span>

                    <span>

                        <i class="fa-solid fa-calendar-days"></i>

                        ${torneo.fecha}

                    </span>

                    <span>

                        <i class="fa-solid fa-layer-group"></i>

                        ${torneo.sistema}

                    </span>

                </div>

            </div>

            <button>

                ${torneo.boton}

            </button>

        </article>

    `;

});